import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class clown extends Actor
    {
    
    
    int score = 0;
    GreenfootImage img = new GreenfootImage("player.png");
    boolean isFlipped = false;
    int power = 3;
    int fireTime = 0;
        
    public clown()
    {

        img.scale(100, 100);
        setImage(img);
        setLocation(600, 650);
    }


         public void act()
     
     {
         MyWorld gameW = (MyWorld) getWorld();
        int xCurr = getX();
        int yCurr = getY();
    
         
         if(Greenfoot.isKeyDown("up") && getY() > 290) 
     
        {
           this.setLocation(getX(), getY()-1); 
        }
        
          if(Greenfoot.isKeyDown("right"))
        {
           this.setLocation(getX()+1, getY());  
        } 
        
        if(Greenfoot.isKeyDown("left")) 
        { 
            this.setLocation(getX()-1, getY()); 
        }
        
         if(Greenfoot.isKeyDown("right") && isFlipped==false) 
        {  
            isFlipped = true;
            img.mirrorHorizontally();
        }
        
        if(Greenfoot.isKeyDown("left") && isFlipped==true) 
        { 
            isFlipped = false;
            img.mirrorHorizontally();
        }
        
        if (Greenfoot.isKeyDown("down") && yCurr < 760) {
            this.setLocation(getX(), getY()+power);
        }
        
             if (fireTime > 0) {
            fireTime--;
        }
        
       if (Greenfoot.isKeyDown("space") && fireTime == 0) {
        fireTime = 60;
        gameW.addObject(new projectile(), getX(), getY());
        }
        
         Actor npc = getOneIntersectingObject(npc.class);

        if (npc != null)
        {
            gameW.playerScore += 10;
            gameW.removeObject(npc);
            return;
        }   
    
          Actor npc2 = getOneIntersectingObject(blowFish.class);
        if(npc2 != null){
           gameW.removeObject(npc2);
           gameW.playerLives = gameW.playerLives - 10;
           return; 
        }
        
        
        }
}
